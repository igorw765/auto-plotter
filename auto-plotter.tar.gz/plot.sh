#!/bin/bash

NUM=1
LOOP=true
PLOTTER="/home/igor/Extra/chia-plotter/"
DEST_T="/mnt/0b28ce18-c35f-43fd-84d0-c07ec84ab0a1/chia-temp"
DEST_P="/mnt/0b28ce18-c35f-43fd-84d0-c07ec84ab0a1/chia-plot"
MNE="today position rail enemy attract cotton today impact brother survey idle butter coffee fabric useless sibling wrong bid buffalo six float congress suspect forward"
MEM=9216
CORES=4


cd $DEST_T
rm -fr *.tmp
cd $PLOTTER

cat logo.txt

while true
do
	if [ -d "$DEST_T" ]
	then
		if [ "$(ls -A $DEST_T)" ]; then
			echo 'not empty'
		else
    	./chia-plotter-linux-amd64 --action plotting -b $MEM -r $CORES -t $DEST_T -d $DEST_P -plotting-cpu 0,1 -plotting-n $NUM -sign-mnemonic $MNE
	sleep 10m
		fi
	else
		echo "Directory $DEST_T not found."
	fi
done
